$(function(){
    
    $('.header-slider').slick({
        arrows: false,
        vertical: true,
        dots: true,
        dotsClass: 'header-dots',
        autoplay: true,
        autoplaySpeed: 4500,
        verticalSwiping: true,
    });

});