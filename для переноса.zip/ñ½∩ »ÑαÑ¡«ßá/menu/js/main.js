let toogle = document.querySelector('.toogle-btn');
let plus = document.querySelector('#plus');


toogle.addEventListener('click', function(){
    let blocks = document.querySelector('.sidebar');


    blocks.classList.toggle('disn');
});


plus.addEventListener('click', function(){
    let block = document.querySelector('.sidebar');

    block.classList.add('disn');
});