import configuration
import telebot
from telebot import types

bot = telebot.TeleBot(configuration.TOKEN)

@bot.message_handler(commands=['start'])
def welcome(message):
	markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
	Monday = types.KeyboardButton('Понедельник')
	Tuesday = types.KeyboardButton('Вторник')
	Wednesday = types.KeyboardButton('Среда')
	Thursday = types.KeyboardButton('Четверг')
	Friday = types.KeyboardButton('Пятница')
	gift = types.KeyboardButton('Подарок')


	markup.add(Monday, Tuesday, Wednesday, Thursday, Friday)

	bot.send_message(message.chat.id, 'Привет, {0.first_name}!С помощью этого бота ты узнаешь цену за дз.'.format(message.from_user), reply_markup = markup)

@bot.message_handler(content_types=['text'])
def texttg(message):
	if message.chat.type == 'private':

		#Подарок
		if message.text == 'Подарок':
			bot.send_message(message.chat.id, 'Скажи Денису что ты нашёл подарок, что бы открыть меню нажми /start ')

		#Все дни недели
		elif message.text == 'Понедельник':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Физикa')
			item2 = types.KeyboardButton('Физкультурa')
			item3 = types.KeyboardButton('Информатикa')
			item4 = types.KeyboardButton('Зарубежная литературa')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2, item3, item4, back)
			
			bot.send_message(message.chat.id, 'Понедельник', reply_markup = markup)

		elif message.text == 'Вторник':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геoграфия')
			item2 = types.KeyboardButton('Xимия')
			item3 = types.KeyboardButton('Геoметрия')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2, item3, back)

			bot.send_message(message.chat.id, 'Вторник', reply_markup = markup)

		elif message.text == 'Среда':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геометрия')
			item2 = types.KeyboardButton('Зарубежная литература')
			item3 = types.KeyboardButton('Физкyльтура')
			item4 = types.KeyboardButton('Биолoгия')
			item5 = types.KeyboardButton('Украинский язык')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item3, item4, item5, back)

			bot.send_message(message.chat.id, 'Среда', reply_markup = markup)

		elif message.text == 'Четверг':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Алгебра')
			item2 = types.KeyboardButton('Информатика')
			item3 = types.KeyboardButton('Физкультура')
			item4 = types.KeyboardButton('Физика')
			item5 = types.KeyboardButton('ОБЖ')
			item6 = types.KeyboardButton('География')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item3, item4, item5, item6, back)

			bot.send_message(message.chat.id, 'Четверг', reply_markup = markup)

		elif message.text == 'Пятница':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Химия')
			item2 = types.KeyboardButton('Биология')
			item3 = types.KeyboardButton('Искусство')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item3, back)

			bot.send_message(message.chat.id, 'Пятница', reply_markup = markup)

		#За понедельник
		elif message.text == 'Физикa':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item2 = types.KeyboardButton('Физкультурa')
			item3 = types.KeyboardButton('Информатикa')
			item4 = types.KeyboardButton('Зарубежная литературa')
			bk = types.KeyboardButton('⬅ Назад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item2, item3, item4, bk, back)
			
			bot.send_message(message.chat.id, 'Физика - 0.25sweat', reply_markup = markup)

		elif message.text == 'Физкультурa':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Физикa')
			item3 = types.KeyboardButton('Информатикa')
			item4 = types.KeyboardButton('Зарубежная литературa')
			bk = types.KeyboardButton('⬅ Назад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item3, item4, bk, back)
			
			bot.send_message(message.chat.id, 'Физкультура - 0.01sweat', reply_markup = markup)

		elif message.text == 'Информатикa':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Физикa')
			item2 = types.KeyboardButton('Физкультурa')
			item4 = types.KeyboardButton('Зарубежная литературa')
			bk = types.KeyboardButton('⬅ Назад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2, item4, bk, back)
			
			bot.send_message(message.chat.id, 'Информатика - 0.25sweat', reply_markup = markup)

		elif message.text == 'Зарубежная литературa':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Физикa')
			item3 = types.KeyboardButton('Информатикa')
			item2 = types.KeyboardButton('Физкультурa')
			bk = types.KeyboardButton('⬅ Назад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2, item3, bk, back)
			
			bot.send_message(message.chat.id, 'Зарубежная литературa - 0.2sweat', reply_markup = markup)

		elif message.text == '⬅ Назад':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Физикa')
			item2 = types.KeyboardButton('Физкультурa')
			item3 = types.KeyboardButton('Информатикa')
			item4 = types.KeyboardButton('Зарубежная литературa')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2, item3, item4, back)
			
			bot.send_message(message.chat.id, '⬅ Назад', reply_markup = markup)

		#За вторник
		elif message.text == 'Геoграфия':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item2 = types.KeyboardButton('Xимия')
			item3 = types.KeyboardButton('Геoметрия')
			bk = types.KeyboardButton('⬅ Hазад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item2, item3, bk, back)

			bot.send_message(message.chat.id, 'География - 0.2sweat, Тест - 0.3sweat', reply_markup = markup)

		elif message.text == 'Xимия':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item2 = types.KeyboardButton('Геoграфия')
			item3 = types.KeyboardButton('Геoметрия')
			bk = types.KeyboardButton('⬅ Hазад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item2, item3, bk, back)

			bot.send_message(message.chat.id, 'Химия - 0.3sweat', reply_markup = markup)

		elif message.text == 'Геoметрия':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item2 = types.KeyboardButton('Геoграфия')
			item3 = types.KeyboardButton('Xимия')
			bk = types.KeyboardButton('⬅ Hазад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item2, item3, bk, back)

			bot.send_message(message.chat.id, 'Геометрия - 0.2sweat, Тест - 0.25sweat', reply_markup = markup)

		elif message.text == '⬅ Hазад':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геoграфия')
			item2 = types.KeyboardButton('Xимия')
			item3 = types.KeyboardButton('Геoметрия')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2, item3, back)

			bot.send_message(message.chat.id, '⬅ Hазад', reply_markup = markup)

		#За среду
		elif message.text == 'Геометрия':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item2 = types.KeyboardButton('Зарубежная литература')
			item3 = types.KeyboardButton('Физкyльтура')
			item4 = types.KeyboardButton('Биолoгия')
			item5 = types.KeyboardButton('Украинский язык')
			bk = types.KeyboardButton('⬅ Haзад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item2 , item3, item4, item5, bk, back)

			bot.send_message(message.chat.id, 'Геометрия - 0.2sweat, Тест - 0.25sweat', reply_markup = markup)

		elif message.text == 'Зарубежная литература':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геометрия')
			item3 = types.KeyboardButton('Физкyльтура')
			item4 = types.KeyboardButton('Биолoгия')
			item5 = types.KeyboardButton('Украинский язык')
			bk = types.KeyboardButton('⬅ Haзад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item3, item4, item5, bk, back)

			bot.send_message(message.chat.id, 'Зарубежная литературa - 0.2sweat', reply_markup = markup)

		elif message.text == 'Физкyльтура':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геометрия')
			item2 = types.KeyboardButton('Зарубежная литература')
			item4 = types.KeyboardButton('Биолoгия')
			item5 = types.KeyboardButton('Украинский язык')
			bk = types.KeyboardButton('⬅ Haзад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item4, item5, bk, back)

			bot.send_message(message.chat.id, 'Физкультура - 0.01sweat', reply_markup = markup)

		elif message.text == 'Биолoгия':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геометрия')
			item2 = types.KeyboardButton('Зарубежная литература')
			item3 = types.KeyboardButton('Физкyльтура')
			item5 = types.KeyboardButton('Украинский язык')
			bk = types.KeyboardButton('⬅ Haзад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item3, item5, bk, back)

			bot.send_message(message.chat.id, 'Биология - 0.3sweat', reply_markup = markup)

		elif message.text == 'Украинский язык':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геометрия')
			item2 = types.KeyboardButton('Зарубежная литература')
			item3 = types.KeyboardButton('Физкyльтура')
			item4 = types.KeyboardButton('Биолoгия')
			bk = types.KeyboardButton('⬅ Haзад')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item3, item4, bk, back)

			bot.send_message(message.chat.id, 'Украинский язык - 0.4sweat', reply_markup = markup)

		elif message.text == '⬅ Haзад':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Геометрия')
			item2 = types.KeyboardButton('Зарубежная литература')
			item3 = types.KeyboardButton('Физкyльтура')
			item4 = types.KeyboardButton('Биолoгия')
			item5 = types.KeyboardButton('Украинский язык')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item3, item4, item5, back)

			bot.send_message(message.chat.id, '⬅ Haзад', reply_markup = markup)
		#За четверг
		elif message.text == 'Физика':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			item1 = types.KeyboardButton('Алгебра')
			item2 = types.KeyboardButton('Информатика')
			item3 = types.KeyboardButton('Физкультура')
			item5 = types.KeyboardButton('ОБЖ')
			item6 = types.KeyboardButton('География')
			back = types.KeyboardButton('⏪ Главное меню')

			markup.add(item1, item2 , item3, item5, item6, back)

			bot.send_message(message.chat.id, 'Физика - 0.25sweat', reply_markup = markup)


		#Для всего
		elif message.text == '⏪ Главное меню':
			markup = types.ReplyKeyboardMarkup(resize_keyboard = True)
			Monday = types.KeyboardButton('Понедельник')
			Tuesday = types.KeyboardButton('Вторник')
			Wednesday = types.KeyboardButton('Среда')
			Thursday = types.KeyboardButton('Четверг')
			Friday = types.KeyboardButton('Пятница')
			gift = types.KeyboardButton('Подарок')


			markup.add(Monday, Tuesday, Wednesday, Thursday, Friday)

			bot.send_message(message.chat.id, '⏪ Главное меню', reply_markup = markup)

bot.polling(none_stop=True)