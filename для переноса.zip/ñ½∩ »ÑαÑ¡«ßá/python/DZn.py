x = float(input('x = ?'))
y = x + 5

print(y)