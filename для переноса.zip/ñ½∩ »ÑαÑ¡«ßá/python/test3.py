from pyowm import OWM

owm = OWM('9de1ad175a005fe113196627f99fdf7d') 

place = input("Какой ваш город?: ")

mgr = owm.weather_manager()
observation = mgr.weather_at_place('place')
w = observation.weather

print(w)
input()