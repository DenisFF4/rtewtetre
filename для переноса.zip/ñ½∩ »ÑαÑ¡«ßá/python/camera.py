import cv2

image = cv2.VideoCapture(0)

while True:
	ret, img = image.read()
	cv2.imshow('Camera', img)
	k = cv2.waitKey(30) & 0xFF
	if k == 27:
		break

image.release()
cv2.destroyAllWindows()