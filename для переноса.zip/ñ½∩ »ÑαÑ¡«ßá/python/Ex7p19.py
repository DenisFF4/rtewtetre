import time
# Завдання 7
fifty_cent = input("Скільки у вас монет по 50 копійок? ")
twentyfive_cent = input("Скільки у вас монет по 25 копійок? ")
ten_cent = input("Скільки у вас монет по 10 копійок? ")
five_cent = input("Скільки у вас монет по 5 копійок? ")
suma = ((50 * int(fifty_cent) + 25 * int(twentyfive_cent) + 10 * int(ten_cent) + 5 * int(five_cent))/100)
print("Всього у вас " + str(suma) + " грн")
input()

# Завдання 10
i = 0
while i <= 100:
	time.sleep(0.1)
	i += 1
	print("Python")
	if i > 100:
		print("Слово Python написано 100 раз ")
input()

# Завдання 8
x = int(input("Введите число : "))
f = 1
for c in range(2, x + 1):
    f *= c
print(f)