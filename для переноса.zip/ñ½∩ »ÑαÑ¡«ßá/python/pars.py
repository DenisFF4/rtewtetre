import datetime
import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

def collect_data(citi_code='2398'):
	cur_time = datetime.datetime.now().strftime('%d_%m_%Y_%H_%M')

	ua = UserAgent()

	print(ua.random)

def main():
	collect_data(citi_code='2398')

if __name__ == '__main__':
	main()