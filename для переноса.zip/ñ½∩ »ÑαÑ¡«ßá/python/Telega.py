import telebot
import config

bot = telebot.TeleBot(config.TOKEN)

@bot.message_handler(content_types=['start'])
def welcome(message):
	bot.send_message(message.chat.id, "Ого, поздравляю!, {0.first_name}!\nЯ - </b> 'Aboba' </b>, Я кролик!".format(message.from_user, bot.get_me()))
	
@bot.message_handler(content_types=['text'])
def lalala(message):
	bot.send_message(message.chat.id, message.text)

bot.polling(none_stop=True)

input()