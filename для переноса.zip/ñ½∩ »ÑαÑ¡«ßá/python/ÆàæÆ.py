n = int(input('Введіть число:'))
print('Введенне число:')
if n > 0:
	print("Додатнє")
elif n < 0:
	print("Відємне")
else:
	print("Нуль")
if abs(n) < 10:
	print("Однозначне")
elif abs(n) >= 10 and abs(n) < 100:
	print("Двозначне")
else:
	print("Багатозначне")
if n % 2 == 0:
	print("Парне")
else:
	print("Не парне")