# age = input("Скільки вам років? ")
# now = input("Какой сейчас год? ")
# x = float(now) - float(age)
# print('Ви ' + str(x) + ' року народження')