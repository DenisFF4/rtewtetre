n = float(input('Вес Даринки? '))
b = n + (n - 5)
m = float(input('Цукерок? '))
g = b - m

print(g)