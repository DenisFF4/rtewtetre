from math import sqrt, pow
# a = 5
# dir(a)
# print(dir(a))

# @2
# myCalc = input("Введіть математичний вираз:\n")
# print(eval(int(myCalc)))

# @3
# txt = "Вова путін хворий хлопець в дупі має жабу, жаба грає вову в дупу - думає, що бабу"
# print(len(txt))

# print(max(231, 12, 3, 183, 1322))
# print(min(231, 12, 3, 183, 1322))

# print(pow(12, 2))

# print(sqrt(pow(3, 2)))

# DZ
cat_1 = input("Введіть довжину першого катета: ")
gip = input("Введіть довжину гіпотенузи: ")
cat_2 = sqrt(pow(int(gip), 2) - pow(int(cat_1), 2))
print("Довжина другого катета " + str(cat_2) + " см")
# Программа не буде працювати якщо корінь не виходить ціле числи