c1 = input('Хто? ')
c2 = input('Де? ')
c3 = input('Коли? ')
c4 = input('Що робив? ')
phrase = c1 + ' ' + c2 + ' в ' + c3 + ' ' + c4 + ' i ' + ' спiвав пiсню' 
print (phrase)

input()