import telebot

bot = telebot.TeleBot("1370999298:AAHctDn6VcvtK01pR4nkF9NiwN83WbzWLAo")

@bot.message_handler(content_types=['text'])
def send_echo(message):
	#bot.reply_to(message, message.text)
    bot.send_message(message.chat.id, message.text)

bot.polling( none_stop = True )