from tkinter import *

# def left_click (event):
# 	my_window.title('Yellowscreen')
# 	my_window.geometry('400x300')
# 	my_window['bg'] = 'yellow'

def right_click (event):
	my_window.title('Bluescreen')
	my_window.geometry('300x200')
	my_window['bg'] = 'blue'
def double_click (event):
	my_window.title('Redscrreen')
	my_window['bg'] = 'red'
	my_window.geometry('300x531')
def booom (event):
	my_window.title('Booomscrreen')
	my_window['bg'] = 'black'
	my_window.geometry('500x600')
def biom (event):
	my_window.title('Booomscrreen')
	my_window['bg'] = 'black'
	my_window.geometry('500x600')
	label1 = Label(my_window, text="I like when my put 10 points ", font= ('Roman'), fg = "white", bg = "black")
	label1.pack()
# def motion (event):
# 	my_window.title('Greenscreen')
# 	my_window['bg'] = 'green'
# 	my_window.geometry('172x412')


my_window = Tk()
my_window.title('Bluescreen')
my_window.geometry('300x200')
my_window['bg'] = 'blue'

label = Label(my_window, text="You fantastic!", font= ('Roman'))
label.pack()
b1 = Button(bg = "pink", width = 12, height = 2, text='Нажми на меня!', fg = "gray", font = "Times 12")
b1.place(x=0, y=-20)
b1.pack()
b2 = Button(bg = "pink", width = 6, height = 2, text='BIB', fg = "white", font = "Times 12")
b2.place(x= 200, y = 20)
b2.pack()
# my_window.bind('<Button-1>', left_click)
my_window.bind('<Button-3>', right_click)
my_window.bind('<Double 1>', double_click)
b1.bind('<Button-1>', booom)
b2.bind('<Button-1>', biom)
# my_window.bind('<Motion>', motion)
my_window.mainloop()