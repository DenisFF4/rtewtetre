# Канкулятор 2
#
from colorama import init
from colorama import Fore, Back, Style

init()

print( Fore.RED )
print( Back.YELLOW )

what = input( "Что делаем? (+, -, *, /): " )

print( Back.CYAN )

a = float( input("Введи первое число: ") )
b = float( input("Введи второе число: ") )

print( Back.GREEN )

if what == "+":
    c = a + b
    print("Результат: " + str(c))
elif what == "-":
	c = a - b
	print("Результат: " + str(c))
elif what == "*":
	c = a * b
	print("Результат: " + str(c))
elif what == "/":
	c = a / b
	print("Результат: " + str(c))
else:
	print("Выбрана неверная операция!")

input()