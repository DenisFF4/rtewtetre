import time
a = input("Сколько тебе лет?\n")
i = 0
print("Проверка...")

while i < 100:
	time.sleep(0.06)
	i += 1
	print(str(i) + "%")
print("Проверка закончена")

if int(a) < 14:
	print("Ты младше меня ")
elif int(a) > 14:
	print("Ты старше меня ")
elif int(a) == 14:
	print("Мы ровесники ")
else:
	print("Проверь, ты правильно написал возраст ")