function calcCartPrice() {
    const cartWrapper = document.querySelector('.cart-wrapper')
    const priceElements = cartWrapper.querySelectorAll('.price__currency')
    const deliveryCost = document.querySelector('.delivery-cost')

    const totalPriceEl = document.querySelector('.total-price')

    let priceTotal = 0

    priceElements.forEach(function (item) {
        const amountEl = item.closest('.cart-item').querySelector('[data-counter]')

        priceTotal += parseInt(item.innerText) * parseInt(amountEl.innerText)
    })

    totalPriceEl.innerText = priceTotal

    if (priceTotal >= 500) {
        deliveryCost.classList.add('free')
        deliveryCost.innerText = 'бесплатно'
    } else {
        deliveryCost.classList.remove('free')
        deliveryCost.innerText = '75 ₴'
    }
} 